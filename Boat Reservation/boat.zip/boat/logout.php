<?php 
include_once('config.php');

session_destroy();

header("location: ../boat/index.php");

 ?>